package com.nsdl.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Degree {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer degreeId;
	private String academicYear;
	private String createdBy;
	private String degreeName;
	private Integer universityId;
	private String updatedBy;
	public Degree() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Degree(Integer degreeId, String academicYear, String createdBy, String degreeName, Integer universityId,
			String updatedBy) {
		super();
		this.degreeId = degreeId;
		this.academicYear = academicYear;
		this.createdBy = createdBy;
		this.degreeName = degreeName;
		this.universityId = universityId;
		this.updatedBy = updatedBy;
	}
	public Integer getDegreeId() {
		return degreeId;
	}
	public void setDegreeId(Integer degreeId) {
		this.degreeId = degreeId;
	}
	public String getAcademicYear() {
		return academicYear;
	}
	public void setAcademicYear(String academicYear) {
		this.academicYear = academicYear;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getDegreeName() {
		return degreeName;
	}
	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}
	public Integer getUniversityId() {
		return universityId;
	}
	public void setUniversityId(Integer universityId) {
		this.universityId = universityId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "Degree [degreeId=" + degreeId + ", academicYear=" + academicYear + ", createdBy=" + createdBy
				+ ", degreeName=" + degreeName + ", universityId=" + universityId + ", updatedBy=" + updatedBy + "]";
	}
	
	

}
