package com.nsdl.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.MarksException;
import com.nsdl.exception.StudentException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Marks;
import com.nsdl.model.Student;
import com.nsdl.model.Subject;
import com.nsdl.repository.MarksRepo;
import com.nsdl.repository.StudentRepo;
import com.nsdl.repository.SubjectRepo;

@Service
public class MarksServiceImpl implements MarksService {
	
	@Autowired
	private MarksRepo marksRepo;
	
	@Autowired
	private StudentRepo studentRepo;
	
	@Autowired
	private SubjectRepo subjectRepo;

	
	@Override
	public Marks addMarks(Marks marks) throws MarksException, StudentException, SubjectException {
		
		 Optional<Student> presentStudent = studentRepo.findById(marks.getStudentId());
			
		  if(presentStudent.isPresent()) {
			  
			  Optional<Subject> presentSubject = subjectRepo.findById(marks.getSubjectId());
			  
			  if(presentSubject.isPresent()) {
				  
//				  Marks presentMarksForSubject = marksRepo.findBySubjectId(marks.getSubjectId());
				  
				 List<Marks> marksList = marksRepo.findBySubjectIdList(marks.getSubjectId());
				  
				  
				 if(marksList.isEmpty()) {
					 
					 return marksRepo.save(marks); 
					 
				 }
				
				 
				 if(marksList!=null) {
					
					List<Marks> marksList2 =  marksRepo.findAll();
				
					
					boolean flag = false;
					
					for(Marks k : marksList2) {
						
						if(k.getStudentId()==marks.getStudentId() && k.getSubjectId()==marks.getSubjectId()) {
							
							flag = true;
						}
						
					}
//					System.out.println(flag);
					if(!flag) {
						return  marksRepo.save(marks); 
					}
					else {
						throw new MarksException("Student with id " + marks.getStudentId() + "have already marks for subject id " + marks.getSubjectId());
					}
				 }
			
				 else {
					 throw new StudentException("Technical error");
				 }
			  }
			  else {
				  throw new SubjectException("No subject present with this id " + marks.getSubjectId());
			  }
			  
		  }
		  else {
			  throw new MarksException("No student present with this id " + marks.getStudentId());
		  }
	}
	

	@Override
	public Marks updateMarks(Marks marks, Integer studentId, Integer subjectId)
			throws MarksException, StudentException, SubjectException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Marks deleteMarks(Integer marksId) throws MarksException {
		// TODO Auto-generated method stub
		return null;
	}



}
