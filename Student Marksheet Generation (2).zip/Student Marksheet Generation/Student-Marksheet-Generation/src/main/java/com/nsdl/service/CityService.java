package com.nsdl.service;

import com.nsdl.exception.CityException;
import com.nsdl.exception.CountryException;
import com.nsdl.exception.StateException;
import com.nsdl.model.City;

public interface CityService {
	
	public City addCity(City city) throws CityException, StateException;
	public City updateCity(City city, String cityName) throws CityException, StateException;
	public String deleteCity(String cityName) throws CityException;
	public City getCityDetails(String cityName) throws CityException;

}
