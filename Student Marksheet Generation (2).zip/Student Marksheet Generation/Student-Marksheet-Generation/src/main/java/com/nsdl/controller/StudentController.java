package com.nsdl.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.CityException;
import com.nsdl.exception.CountryException;
import com.nsdl.exception.DateException;
import com.nsdl.exception.StateException;
import com.nsdl.exception.StudentException;
import com.nsdl.exception.UniversityException;
import com.nsdl.model.Student;
import com.nsdl.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@PostMapping("/addStudent")
	public ResponseEntity<Student> addStudentHandler(@RequestBody Student student) throws CountryException, StudentException, CityException, StateException, UniversityException, DateException{
		
		return new ResponseEntity<Student>(studentService.addStudent(student), HttpStatus.OK);
	}
	
	@GetMapping("/getExcel/{roll}/{name}")
	public ResponseEntity<String> generateExcelFileHandler(HttpServletResponse response,@PathVariable("roll") Integer rollNumber,@PathVariable("name") String degreeName) throws IOException, StudentException{
		
		
		response.setContentType("application/octet-stream");
		String headerKey = "Content-Disposition";
		String headerValue = "attachment;filename=student.xls";
		
		response.setHeader(headerKey, headerValue);
		
		return new ResponseEntity<String>(studentService.generateExcel(response,rollNumber,degreeName),HttpStatus.OK);
		
	}

}
