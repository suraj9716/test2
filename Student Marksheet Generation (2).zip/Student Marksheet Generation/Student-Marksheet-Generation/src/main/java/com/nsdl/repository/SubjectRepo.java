package com.nsdl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nsdl.model.Subject;

public interface SubjectRepo extends JpaRepository<Subject, Integer> {
	
	public Subject findBySubjectName(String subjectName);
	
	@Query(value = "select *  from subject where degree_id = :id",nativeQuery = true)
	public List<Subject> findSubjectList(@Param("id") Integer id);

}
