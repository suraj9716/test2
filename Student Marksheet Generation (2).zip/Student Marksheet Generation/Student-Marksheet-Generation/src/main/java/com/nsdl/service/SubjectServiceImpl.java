package com.nsdl.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.DegreeException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Degree;
import com.nsdl.model.Subject;
import com.nsdl.repository.DegreeRepo;
import com.nsdl.repository.SubjectRepo;

@Service
public class SubjectServiceImpl implements SubjectService {
	
	@Autowired
	private SubjectRepo subjectRepo;
	
	@Autowired
	private DegreeRepo degreeRepo;

	@Override
	public Subject addSubject(Subject subject) throws SubjectException, DegreeException {
		
	 Subject presentSubject = subjectRepo.findBySubjectName(subject.getSubjectName());
	 
	 if(presentSubject==null) {
		 
		Optional<Degree> presentDegree =  degreeRepo.findById(subject.getDegreeId());
		
		if(presentDegree.isPresent()) {
			
			 return subjectRepo.save(subject);
		}
		else {
			throw new DegreeException("No degree present with this id " + subject.getDegreeId());
		}
	 }
	 else {
		 throw new SubjectException("No subjecrt present with this name " + subject.getSubjectName());
	 }
	 
	}

	@Override
	public Subject updateSubject(Subject subject, String subjectName) throws SubjectException, DegreeException {
		
		 Subject presentSubject = subjectRepo.findBySubjectName(subjectName);
		 
		 if(presentSubject!=null) {
			 
			 Optional<Degree> presentDegree = degreeRepo.findById(subject.getDegreeId());
			 
			 if(presentDegree.isPresent()) {
				 
				 presentSubject.setSubjectId(presentSubject.getSubjectId());
				 presentSubject.setCreatedBy(subject.getCreatedBy());
				 presentSubject.setDegreeId(subject.getDegreeId());
				 presentSubject.setMinMarks(subject.getMinMarks());
				 presentSubject.setSubjectName(subject.getSubjectName());
				 presentSubject.setTotalMarks(subject.getTotalMarks());
				 presentSubject.setUpdatedBy(subject.getUpdatedBy());
				 presentSubject.setYear(subject.getYear());
				 
				 return subjectRepo.save(presentSubject);
			 }
			 else {
				 throw new DegreeException("No degree present with this id " + subject.getDegreeId());
			 }
			 
		 }
		 else {
			 throw new SubjectException("No subject present with this name " + subjectName);
		 }
		 
	}

	@Override
	public String deleteSubject(String subjectName) throws SubjectException {
		
		String message = "Technical Error";
		
		 Subject presentSubject = subjectRepo.findBySubjectName(subjectName);
		 
		 if(presentSubject!=null) {
			 subjectRepo.delete(presentSubject);
			 return message = "Subject Deleted Successfully";
		 }
		 else {
			 throw new SubjectException("No subject present with this name " +   subjectName);
		 }
	}

	@Override
	public Subject getSubjectDetails(String subjectName) throws SubjectException {
		
		Subject presentSubject = subjectRepo.findBySubjectName(subjectName);
		 
		 if(presentSubject!=null) {
			
			 return presentSubject;
		 }
		 else {
			 throw new SubjectException("No subject present with this name " +   subjectName);
		 }
	}

}
