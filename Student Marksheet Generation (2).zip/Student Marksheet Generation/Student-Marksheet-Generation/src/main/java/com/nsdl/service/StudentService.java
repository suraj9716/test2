package com.nsdl.service;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import com.nsdl.exception.CityException;
import com.nsdl.exception.CountryException;
import com.nsdl.exception.DateException;
import com.nsdl.exception.StateException;
import com.nsdl.exception.StudentException;
import com.nsdl.exception.UniversityException;
import com.nsdl.model.Student;

public interface StudentService {
	
	public Student addStudent(Student student) throws StudentException,CityException, CountryException, StateException,UniversityException, DateException;
	public Student updateStudent(Student student, Integer rollNo)  throws StudentException,CityException, CountryException, StateException,UniversityException;
	public String generateExcel(HttpServletResponse response, Integer rollNumber, String degreeName)throws IOException , StudentException;
	public String generatePdf(HttpServletResponse response) throws IOException,StudentException;
}
