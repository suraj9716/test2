package com.nsdl.exception;

public class DegreeException extends Exception {

	public DegreeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DegreeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
