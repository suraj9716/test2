package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.CountryException;
import com.nsdl.model.Country;
import com.nsdl.service.CountryService;

@RestController
public class CountryController {
	
	@Autowired
	private CountryService countryService;
	
	@PostMapping("/addCountry")
	public ResponseEntity<Country> addCountryHandler(@RequestBody Country country) throws CountryException{
		
		return new ResponseEntity<Country>(countryService.addCountry(country), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteCountry/{name}")
	public ResponseEntity<String> deleteCountryHandler(@PathVariable("name") String name) throws CountryException{
		
		return new ResponseEntity<String>(countryService.deleteCountry(name), HttpStatus.OK);
	}
	
	@PutMapping("/updateCountry")
	public ResponseEntity<Country> updateCountryHandler(@RequestBody Country country) throws CountryException{
		
		return new ResponseEntity<Country>(countryService.updateCountry(country), HttpStatus.OK);
	}
	
	@GetMapping("/getCountryDetailsWithName/{name}")
	public ResponseEntity<Country> getCountryDetailsByCountryNameHandler(@PathVariable("name") String countryName) throws CountryException{
		
		return new ResponseEntity<Country>(countryService.getCountryDetailsByCountryName(countryName), HttpStatus.OK);
	}

}
