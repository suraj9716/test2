package com.nsdl.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer studentId;
	 private Integer cityId;
	private Integer countryId;
	private String createdBy;
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate createdOnDate;
    private String studentName;
    private Integer rollNumber;
    private Integer stateId;
    private Integer universityId;
    @JsonFormat(pattern="yyyy-MM-dd")
    private LocalDate updateOnDate;
    private String updatedBy;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Integer studentId, Integer cityId, Integer countryId, String createdBy, LocalDate createdOnDate,
			String studentName, Integer rollNumber, Integer stateId, Integer universityId, LocalDate updateOnDate,
			String updatedBy) {
		super();
		this.studentId = studentId;
		this.cityId = cityId;
		this.countryId = countryId;
		this.createdBy = createdBy;
		this.createdOnDate = createdOnDate;
		this.studentName = studentName;
		this.rollNumber = rollNumber;
		this.stateId = stateId;
		this.universityId = universityId;
		this.updateOnDate = updateOnDate;
		this.updatedBy = updatedBy;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public Integer getCityId() {
		return cityId;
	}
	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public LocalDate getCreatedOnDate() {
		return createdOnDate;
	}
	public void setCreatedOnDate(LocalDate createdOnDate) {
		this.createdOnDate = createdOnDate;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Integer getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	public Integer getUniversityId() {
		return universityId;
	}
	public void setUniversityId(Integer universityId) {
		this.universityId = universityId;
	}
	public LocalDate getUpdateOnDate() {
		return updateOnDate;
	}
	public void setUpdateOnDate(LocalDate updateOnDate) {
		this.updateOnDate = updateOnDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", cityId=" + cityId + ", countryId=" + countryId + ", createdBy="
				+ createdBy + ", createdOnDate=" + createdOnDate + ", studentName=" + studentName + ", rollNumber="
				+ rollNumber + ", stateId=" + stateId + ", universityId=" + universityId + ", updateOnDate="
				+ updateOnDate + ", updatedBy=" + updatedBy + "]";
	}
    
    
   
  
  

    
    

}
