package com.nsdl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nsdl.model.Grade;

public interface GradeRepo extends JpaRepository<Grade, Integer> {
	
	public Grade findByGradeName(String gradeName);
	
	public Grade findBySubjectId(Integer subjectId);
	
	@Query(value = "select * from grade  where grade_name = :name", nativeQuery = true)
	public List<Grade> findListByGradeName(@Param("name") String gradeName);

}
