package com.nsdl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nsdl.model.Student;

public interface StudentRepo extends JpaRepository<Student, Integer> {
	
	public Student findByRollNumber(Integer rollNumber);
	

}
