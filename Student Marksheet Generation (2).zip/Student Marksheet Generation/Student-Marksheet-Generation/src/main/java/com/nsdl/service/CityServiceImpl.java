package com.nsdl.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.CityException;
import com.nsdl.exception.CountryException;
import com.nsdl.exception.StateException;
import com.nsdl.model.City;
import com.nsdl.model.State;
import com.nsdl.repository.CityRepo;
import com.nsdl.repository.CountryRepo;
import com.nsdl.repository.StateRepo;

@Service
public class CityServiceImpl implements CityService {
	
	@Autowired
	private CityRepo cityRepo;
	
	@Autowired
	private StateRepo stateRepo;
	
	@Autowired
	private CountryRepo countryRepo;

	@Override
	public City addCity(City city) throws CityException, StateException {
		
		City presentCity = cityRepo.findByCityName(city.getCityName());


		if(presentCity!=null) {
			
			throw new CityException("City already present with this name " + city.getCityName());
		}
		else {
			
			 Optional<State> presentState =  stateRepo.findById(city.getStateId());
			
			if(presentState.isPresent()) {
				return cityRepo.save(city);
			}
			else {
				throw new StateException("No state present with this id " + city.getStateId());
			}
		}
	}

	@Override
	public City updateCity(City city, String cityName) throws CityException, StateException {
		
		City presentCity =  cityRepo.findByCityName(cityName);
		
		Optional<City> cityId = cityRepo.findById(city.getCityId());
		
		if(presentCity!=null) {
			
			if(cityId.isPresent()) {
				
				Optional<State> presentSate = stateRepo.findById(city.getStateId());
				
				if(presentSate.isPresent()) {
					
					presentCity.setCityId(presentCity.getCityId());
					presentCity.setCityName(city.getCityName());
					presentCity.setStateId(city.getStateId());
					
					return cityRepo.save(presentCity);
				}
				else {
					throw new StateException("No state present with this id " +  city.getStateId());
				}
				
			}
			else {
				throw new CityException("No city present with this id " + city.getCityId());
			}
		}
		else {
			throw new CityException("No city present with this name " +  cityName);
		}
		
	}

	@Override
	public String deleteCity(String cityName) throws CityException {
		
		String message = "Technical Error";
		
		City presentCity =  cityRepo.findByCityName(cityName);
		
		if(presentCity!=null) {
			
			cityRepo.delete(presentCity);
			return message = "City Deleted Successfully";
		
		}
		else {
			throw new CityException("No city present with this name " + cityName);
		}
		
	}

	@Override
	public City getCityDetails(String cityName) throws CityException {
		
		City presentCity =  cityRepo.findByCityName(cityName);
		
		if(presentCity!=null) {
			
			return presentCity;
		}
		else {
			throw new CityException("No city present with this name " +  cityName);
		}
	}

}
