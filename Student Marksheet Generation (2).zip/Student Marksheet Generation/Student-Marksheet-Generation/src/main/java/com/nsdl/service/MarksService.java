package com.nsdl.service;

import com.nsdl.exception.MarksException;
import com.nsdl.exception.StudentException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Marks;

public interface MarksService {
	
	public Marks addMarks(Marks marks) throws MarksException,StudentException, SubjectException;;
	public Marks updateMarks(Marks marks , Integer studentId, Integer subjectId) throws MarksException, StudentException, SubjectException;
	public Marks deleteMarks(Integer marksId) throws MarksException;

}
