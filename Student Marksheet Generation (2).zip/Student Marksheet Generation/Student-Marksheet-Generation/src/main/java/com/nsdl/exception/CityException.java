package com.nsdl.exception;

public class CityException extends Exception {

	public CityException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
