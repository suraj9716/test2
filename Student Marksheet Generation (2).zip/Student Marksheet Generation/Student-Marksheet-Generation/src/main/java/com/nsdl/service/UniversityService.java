package com.nsdl.service;

import com.nsdl.exception.UniversityException;
import com.nsdl.model.University;

public interface UniversityService {
	
	public University addUniversity(University university) throws UniversityException;
	public University updateUniversity(University university , String universirtyName) throws UniversityException;
	public String deleteUniversity(String univesityName) throws UniversityException;
	public University getUniversityDetails(String universityName) throws UniversityException;

}
