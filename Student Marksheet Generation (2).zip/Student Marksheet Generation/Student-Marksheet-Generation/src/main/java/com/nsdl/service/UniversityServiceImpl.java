package com.nsdl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.UniversityException;
import com.nsdl.model.University;
import com.nsdl.repository.UniversityRepo;

@Service
public class UniversityServiceImpl implements UniversityService {
	
	
	@Autowired
	private UniversityRepo universityRepo;

	@Override
	public University addUniversity(University university) throws UniversityException {
		University presentUniversity =  universityRepo.findByUniversityName(university.getUniversityName());
		
		if(presentUniversity==null) {
			
			return universityRepo.save(university);
		}
		else {
			throw new UniversityException("University already present with this name " + university.getUniversityName());
		}
	}

	@Override
	public University updateUniversity(University university, String universirtyName) throws UniversityException {
	University presentUniversity =  universityRepo.findByUniversityName(universirtyName);
		
		if(presentUniversity!=null) {
			
			presentUniversity.setUniversityId(presentUniversity.getUniversityId());
			presentUniversity.setUniversityName(university.getUniversityName());
			
			return universityRepo.save(presentUniversity);
		}
		else {
			throw new UniversityException("No university presnet with this name " + universirtyName);
		}
	}

	@Override
	public String deleteUniversity(String univesityName) throws UniversityException {
		
		String message = "Technical Error";
		
		 University presentUniversity =  universityRepo.findByUniversityName(univesityName);
		
		if(presentUniversity!=null) {
			
			universityRepo.delete(presentUniversity);
			message = "University Deleted Successfully";
			return message;
		}
		else {
			throw new UniversityException("No university present with this name " + univesityName);
		}
	}

	@Override
	public University getUniversityDetails(String universityName) throws UniversityException {
		
		 University presentUniversity =  universityRepo.findByUniversityName(universityName);
		 
		 if(presentUniversity!=null) {
			 
			 return presentUniversity;
		 }
		 else {
			 throw new UniversityException("No university present with this name " + universityName);
		 }
		
	}
	
	

}
