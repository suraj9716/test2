package com.nsdl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nsdl.model.Degree;

public interface DegreeRepo extends JpaRepository<Degree, Integer> {
	
	public Degree findByAcademicYear(String academicYear);
	public Degree findByCreatedBy(String createdBy);
	public Degree findByDegreeName(String degreeName);
	
	@Query(value = "select *  from degree d, university u where d.university_id = :id", nativeQuery = true)
	public List<Degree> findDegree(Integer id);

}
