package com.nsdl.service;

import com.nsdl.exception.CountryException;
import com.nsdl.exception.StateException;
import com.nsdl.model.State;

public interface StateService {
	
	public State addState(State state) throws StateException, CountryException;
	public State updateState(State state, String stateName) throws StateException,CountryException;
	public String deleteState(String stateName) throws StateException;
    public State getStateDetails(String stateName) throws StateException;

}
