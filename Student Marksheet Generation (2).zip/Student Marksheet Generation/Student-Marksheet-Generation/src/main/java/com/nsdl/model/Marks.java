package com.nsdl.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Marks {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer marksId;
	private Integer marksObtained;
	private Integer StudentId;
	private Integer subjectId;
	public Marks() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Marks(Integer marksId, Integer marksObtained, Integer studentId, Integer subjectId) {
		super();
		this.marksId = marksId;
		this.marksObtained = marksObtained;
		StudentId = studentId;
		this.subjectId = subjectId;
	}
	public Integer getMarksId() {
		return marksId;
	}
	public void setMarksId(Integer marksId) {
		this.marksId = marksId;
	}
	public Integer getMarksObtained() {
		return marksObtained;
	}
	public void setMarksObtained(Integer marksObtained) {
		this.marksObtained = marksObtained;
	}
	public Integer getStudentId() {
		return StudentId;
	}
	public void setStudentId(Integer studentId) {
		StudentId = studentId;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}
	@Override
	public String toString() {
		return "Marks [marksId=" + marksId + ", marksObtained=" + marksObtained + ", StudentId=" + StudentId
				+ ", subjectId=" + subjectId + "]";
	}
	
	

}
