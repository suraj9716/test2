package com.nsdl.model;

public class HashTable {
	
	private Integer id;
	
	private Integer studentId;
	private Integer subjectId;
	
	
	public HashTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HashTable(Integer studentId, Integer subjectId) {
		super();
		
		this.studentId = studentId;
		this.subjectId = subjectId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}


	
	

}
