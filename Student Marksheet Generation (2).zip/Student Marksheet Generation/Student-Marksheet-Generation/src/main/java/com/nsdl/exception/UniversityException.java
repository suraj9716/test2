package com.nsdl.exception;

public class UniversityException extends Exception{

	public UniversityException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UniversityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
