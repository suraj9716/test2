package com.nsdl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.CountryException;
import com.nsdl.model.Country;
import com.nsdl.repository.CountryRepo;

@Service
public class CountryServiceImpl implements CountryService{
	
	@Autowired
	private CountryRepo countryRepo;

	@Override
	public Country addCountry(Country country) throws CountryException {
		
		Country presentCountry = countryRepo.findByCountryName(country.getCountryName());
		
		if(presentCountry==null) {
			
		return countryRepo.save(country);
		
		}
		else {
			throw new CountryException("Country already present with name " + country.getCountryName()+ " with id " +  country.getCountryId());
		}
	}

	@Override
	public String deleteCountry(String CountryName) throws CountryException {
		
		String message = "Technical Error";
		
		Country presentCountry = countryRepo.findByCountryName(CountryName);
		
		if(presentCountry==null) {
			
			throw new CountryException("No country found with this name " + CountryName);
		}
		else {
			countryRepo.delete(presentCountry);
			message = "Country Deleted Successfully";
			
		}
		return message;
	}

	@Override
	public Country updateCountry(Country country) throws CountryException {
		Country presentCountry = countryRepo.findByCountryId(country.getCountryId());
	
		
		if(presentCountry!=null) {
			
				presentCountry.setCountryName(country.getCountryName());
				
				return countryRepo.save(presentCountry);
		}
		
		else 
		{
			throw new CountryException("no country found with this name " +  country.getCountryName());
		}
	}

	@Override
	public Country getCountryDetailsByCountryName(String countryName) throws CountryException {
		
		Country presentCountry = countryRepo.findByCountryName(countryName);
		String name ="";
		Country presentCountry2 = null;
		if(presentCountry!=null) {
			
				System.out.println(presentCountry);
				
				return presentCountry;
		}
		
		if(presentCountry==null) {
			
			for(int i =0;i<countryName.length();i++) {
				
				if(i==0) {
					name += countryName.toUpperCase().charAt(i);
				}
				else {
					name += countryName.charAt(i);
				}
			}
			
			System.out.println("nnn" + name);
			
			presentCountry2 = countryRepo.findByCountryName(name);
			
			System.out.println(presentCountry2);
			
			if(presentCountry2==null) {
				throw new CountryException("No Country found with this name " +  name);
			}
			
			return presentCountry2;
			
		}
		else {
			throw new CountryException("no country present with this name " +  countryName);
		}
		
	}
	
	

}
