package com.nsdl.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Subject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer subjectId;
	private String createdBy;
	private Integer degreeId;
	private Integer minMarks;
	private String subjectName;
	private Integer totalMarks;
	private String updatedBy;
	private String year;
	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Subject(Integer subjectId, String createdBy, Integer degreeId, Integer minMarks, String subjectName,
			Integer totalMarks, String updatedBy, String year) {
		super();
		this.subjectId = subjectId;
		this.createdBy = createdBy;
		this.degreeId = degreeId;
		this.minMarks = minMarks;
		this.subjectName = subjectName;
		this.totalMarks = totalMarks;
		this.updatedBy = updatedBy;
		this.year = year;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getDegreeId() {
		return degreeId;
	}
	public void setDegreeId(Integer degreeId) {
		this.degreeId = degreeId;
	}
	public Integer getMinMarks() {
		return minMarks;
	}
	public void setMinMarks(Integer minMarks) {
		this.minMarks = minMarks;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public Integer getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(Integer totalMarks) {
		this.totalMarks = totalMarks;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "Subject [subjectId=" + subjectId + ", createdBy=" + createdBy + ", degreeId=" + degreeId + ", minMarks="
				+ minMarks + ", subjectName=" + subjectName + ", totalMarks=" + totalMarks + ", updatedBy=" + updatedBy
				+ ", year=" + year + "]";
	}
	
	

}
