package com.nsdl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nsdl.model.University;

public interface UniversityRepo extends JpaRepository<University, Integer>{
	
	public University findByUniversityName(String universityName);
	
	public University findByUniversityId(Integer universityId);

}
