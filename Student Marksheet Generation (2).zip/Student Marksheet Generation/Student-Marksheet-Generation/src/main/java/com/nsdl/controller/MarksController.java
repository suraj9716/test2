package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.MarksException;
import com.nsdl.exception.StudentException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Marks;
import com.nsdl.service.MarksService;

@RestController
public class MarksController {
	
	@Autowired
	private MarksService marksService;
	
	@PostMapping("/addMarks")
	public ResponseEntity<Marks> addMarksHandler(@RequestBody Marks marks) throws MarksException, StudentException, SubjectException{
		
		return new ResponseEntity<Marks>(marksService.addMarks(marks), HttpStatus.OK);
	}

}
