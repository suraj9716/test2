package com.nsdl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nsdl.model.Country;

public interface CountryRepo extends JpaRepository<Country, Integer> {
	
	public Country findByCountryName(String countryName);
	public Country findByCountryId(Integer countryId);

}
