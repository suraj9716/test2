package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.UniversityException;
import com.nsdl.model.University;
import com.nsdl.service.UniversityService;

import io.swagger.models.Response;

@RestController
public class UniversityController {
	
	@Autowired
	private UniversityService universityService;
	
	@PostMapping("/addUniversity")
	public ResponseEntity<University> addUniversityHandler( @RequestBody University university) throws UniversityException{
		
		return new ResponseEntity<University>(universityService.addUniversity(university), HttpStatus.OK);
	}
	
	@PutMapping("/updateUniversity/{universityName}")
	public ResponseEntity<University> updateUniversityHandler(@RequestBody University university, @PathVariable("universityName") String universityName) throws UniversityException{
		
		return new ResponseEntity<University>(universityService.updateUniversity(university, universityName), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteUniversity/{universityName}")
	public ResponseEntity<String> deleteUniversityHandler(@PathVariable("universityName") String universityName) throws UniversityException{
		
		return new ResponseEntity<String>(universityService.deleteUniversity(universityName), HttpStatus.OK);
	}
	
	@GetMapping("/getUniversityDetails/{universityName}")
	public ResponseEntity<University> getUniversityDetailsHandler(@PathVariable("universityName") String universityName) throws UniversityException{
		
		return new ResponseEntity<University>(universityService.getUniversityDetails(universityName), HttpStatus.OK);
	}

}
