package com.nsdl.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.GradeException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Grade;
import com.nsdl.model.Subject;
import com.nsdl.repository.GradeRepo;
import com.nsdl.repository.SubjectRepo;

@Service
public class GradeServiceImpl implements GradeService {
	
	@Autowired
	private GradeRepo gradeRepo;
	
	@Autowired
    private SubjectRepo subjectRepo;
    
	
	@Override
	public Grade addGrade(Grade grade) throws GradeException, SubjectException {
		
//	List<Grade> presentGrade = (List<Grade>) gradeRepo.findByGradeName(grade.getGradeName());
	
	List<Grade> presentGradeList = gradeRepo.findListByGradeName(grade.getGradeName());
	
	boolean flag = false;
	
   for(Grade k : presentGradeList) {
	   
	   if(k.getGradeName().equals(grade.getGradeName()) && k.getSubjectId()==grade.getSubjectId()) {
		   
		   flag = true;
	   }
	   
   }
   
   if(!flag) {
	   Optional<Subject> presentSubject = subjectRepo.findById(grade.getSubjectId());
		
		if(presentSubject.isPresent()) {
			
			return gradeRepo.save(grade);
		}else {
			throw new SubjectException("No subject present with this id " + grade.getSubjectId());
		}
   }
   else {
	   throw new GradeException("Grade " + grade.getGradeName() +" already present for subject id " +  grade.getSubjectId());
   }
	
//	Grade presentGrade2 = gradeRepo.findBySubjectId(grade.getSubjectId());
	
//	if(presentGrade==null) {
//	
//		
//		Optional<Subject> presentSubject = subjectRepo.findById(grade.getSubjectId());
//		
//		if(presentSubject.isPresent()) {
//			
//			return gradeRepo.save(grade);
//		}else {
//			throw new SubjectException("No subject present with this id " + grade.getSubjectId());
//		}
//		
//		
//	   }

	
//	if(presentGrade.get(0).getSubjectId()==grade.getSubjectId()) {
//		
//		throw new GradeException("Grade already present with this name " + grade.getGradeName());
//	}
//	
//	else {
//		
//	Optional<Subject> presentSubject = subjectRepo.findById(grade.getSubjectId());
//		
//		if(presentSubject.isPresent()) {
//			
//			return gradeRepo.save(grade);
//		}else {
//			throw new SubjectException("No subject present with this id " + grade.getSubjectId());
//		}
		
	
	
//	else {
//		throw new GradeException("Grade already present with this name " + grade.getGradeName());
//	 }
	}

	@Override
	public Grade updateGrade(Grade grade, Integer subjectId) throws GradeException, SubjectException {
		
		Grade presentGrade = gradeRepo.findByGradeName(grade.getGradeName());
		
//		System.out.println(presentGrade);
		
		if(presentGrade!=null) {
			
			Optional<Subject> presentSubject = subjectRepo.findById(subjectId);
			Optional<Subject> presentSubject2 = subjectRepo.findById(grade.getSubjectId());
			
			if(presentSubject.isPresent()) {
				
				if(presentSubject2.isPresent()) {
					
					presentGrade.setGradeId(presentGrade.getGradeId());
					presentGrade.setCreatedBy(grade.getCreatedBy());
					presentGrade.setGradeName(grade.getGradeName());
					presentGrade.setRangeFrom(grade.getRangeFrom());
					presentGrade.setRangeTo(grade.getRangeTo());
					presentGrade.setSubjectId(grade.getSubjectId());
					presentGrade.setUpdatedBy(grade.getUpdatedBy());
					
					return gradeRepo.save(presentGrade);
				}
				else {
					throw new SubjectException("No subject present with this id " + grade.getSubjectId());
				}
			
				
			}
			else {
				throw new SubjectException("No subject present with this id " + subjectId);
			}
		}
		
		throw new GradeException("No grade found with this name " + grade.getGradeName());
	}

	@Override
	public String deleteGrade(String gradeName) throws GradeException {
		
		String message = "Technical Error";
		
		Grade presentGrade = gradeRepo.findByGradeName(gradeName);
		
		if(presentGrade!=null) {
			gradeRepo.delete(presentGrade);
			message = "Grade Deleted Successfully";
			return message;
		}
		else {
			throw new GradeException("No grade present with this name " + gradeName); 
		}
	}

	@Override
	public Grade getGradeDetails(String gradeName) throws GradeException {
		
		Grade presentGrade = gradeRepo.findByGradeName(gradeName);
		
		if(presentGrade!=null) {
			return presentGrade;
		}
		else {
			throw new GradeException("No grade present with this name " +  gradeName);
		}
	}
	
	

}
