package com.nsdl.service;

import com.nsdl.exception.CountryException;
import com.nsdl.model.Country;

public interface CountryService {
	
	public Country addCountry(Country country) throws CountryException;
	public String deleteCountry(String CountryName) throws CountryException;
	public Country updateCountry(Country country) throws CountryException;
	public Country getCountryDetailsByCountryName(String countryName) throws CountryException;

}
