package com.nsdl.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nsdl.model.Marks;
import com.nsdl.model.ReportCard;

@Transactional
public interface MarksRepo extends JpaRepository<Marks, Integer> , JpaSpecificationExecutor<Marks>{
	
	public Marks findBySubjectId(Integer subjectId);
	
	@Query(value = "select * from marks where subject_id = :id", nativeQuery = true)
	public List<Marks> findBySubjectIdList(@Param("id") Integer subjectId);
	
	
//	@Query("select new com.nsdl.model.ReportCard(m.StudentId as StudentId ,m.subjectId as subjectId ,m.marksObtained as marksObtained, s.rollNumber as rollNumber, s.universityId as universityId ,s2.degreeId as degreeId ,s2.minMarks as minMarks ,s2.totalMarks as totalMarks ,s2.subjectName as subjectName ,s2.year as year,s.studentName as studentName,g.gradeName as gradeName )  from Marks m inner join Student s on s.studentId = m.StudentId inner join Subject s2 on m.subjectId = s2.subjectId"
//			+ " inner join Grade g on s2.subjectId = g.subjectId "
//			+ " where s.rollNumber = :roll and m.marksObtained between g.rangeFrom and g.rangeTo")
//	public List<ReportCard> findAllDetails(@Param("roll") Integer roll);
	
	@Query("select new com.nsdl.model.ReportCard(m.StudentId as StudentId ,m.subjectId as subjectId ,m.marksObtained as marksObtained, s.rollNumber as rollNumber, s.universityId as universityId ,s2.degreeId as degreeId ,s2.minMarks as minMarks ,s2.totalMarks as totalMarks ,s2.subjectName as subjectName ,s2.year as year,s.studentName as studentName,g.gradeName as gradeName, d.degreeName as degreeName )  from Marks m inner join Student s on s.studentId = m.StudentId inner join Subject s2 on m.subjectId = s2.subjectId"
			+ " inner join Grade g on s2.subjectId = g.subjectId inner join Degree d on s2.degreeId = d.degreeId"
			+ " where s.rollNumber = :roll and d.degreeName = :name and m.marksObtained between g.rangeFrom and g.rangeTo")
	public List<ReportCard> findAllDetails(@Param("roll") Integer roll, @Param("name") String name);
	
	/*
	 * @Query("select new com.nsdl.model.ReportCard(m.StudentId as StudentId ,m.subjectId as subjectId ,m.marksObtained as marksObtained, s.rollNumber as rollNumber, s.universityId as    universityId ,s2.degreeId as degreeId ,s2.minMarks as minMarks ,s2.totalMarks as totalMarks ,s2.subjectName as subjectName ,s2.year as year,s.studentName as studentName , g.gradeName as gradeName) from Marks m inner join Student s on s.student_id = m.Student_id inner join Subject s2 on m.subjectId = s2.subjectId inner join Grade g on g.subjectId = s2.subjectId where s.rollNumber =?1 and m.marksObtained between g.rangeFrom and g.rangeTo"
	 * ) public List<ReportCard> findAllDetails(Integer roll);
	 */
   

   
   
   
//	@Query(value = "select new com.nsdl.model.HashTable(m.student_id , m.subject_id)  from marks m inner join student s on s.student_id = m.student_id where s.roll_number = :roll", nativeQuery = true)
//	public List<HashTable> getHash(@Param("roll") Integer roll);
	
	
//	@Query(value = "select *  from marks m inner join student s on s.student_id = m.student_id where s.roll_number = :roll", nativeQuery = true)
//	public List<Marks> getHash(@Param("roll") Integer roll);
}
