package com.nsdl.service;

import com.nsdl.exception.GradeException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Grade;

public interface GradeService {
	
	public Grade addGrade(Grade grade) throws GradeException, SubjectException;
	public Grade updateGrade(Grade grade, Integer subjectId)  throws GradeException, SubjectException;
	public String deleteGrade(String gradeName) throws GradeException;
	public Grade getGradeDetails(String gradeName) throws GradeException;

}
