package com.nsdl.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.nsdl.exception.CityException;
import com.nsdl.exception.CountryException;
import com.nsdl.exception.DateException;
import com.nsdl.exception.StateException;
import com.nsdl.exception.StudentException;
import com.nsdl.exception.UniversityException;
import com.nsdl.model.City;
import com.nsdl.model.Country;
import com.nsdl.model.Degree;
import com.nsdl.model.HashTable;
import com.nsdl.model.Marks;
import com.nsdl.model.ReportCard;
import com.nsdl.model.State;
import com.nsdl.model.Student;
import com.nsdl.model.Subject;
import com.nsdl.model.University;
import com.nsdl.repository.CityRepo;
import com.nsdl.repository.CountryRepo;
import com.nsdl.repository.DegreeRepo;
import com.nsdl.repository.MarksRepo;
import com.nsdl.repository.StateRepo;
import com.nsdl.repository.StudentRepo;
import com.nsdl.repository.SubjectRepo;
import com.nsdl.repository.UniversityRepo;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepo studentRepo;
	
	@Autowired
	private CityRepo cityRepo;
	
	@Autowired
	private CountryRepo countryrepo;
	
	@Autowired
	private StateRepo stateRepo;
	
	@Autowired
	private UniversityRepo universityRepo;
	
	
	@Autowired
	private DegreeRepo degreeRepo;
	
	@Autowired
	private MarksRepo marksRepo;
	
	@Autowired
	private SubjectRepo subjectRepo;

	@Override
	public Student addStudent(Student student)
			throws StudentException, CityException, CountryException, StateException, UniversityException, DateException {
		
		Student presentStudent =  studentRepo.findByRollNumber(student.getRollNumber());
	
		
		
		if(presentStudent==null) {
		
			
			Optional<University> presentUniversity = universityRepo.findById(student.getUniversityId());
			
			if(presentUniversity.isPresent()) {
				
			Optional<Country> presentCountry = 	countryrepo.findById(student.getCountryId());
			
			if(presentCountry.isPresent()) {
				
				
				Optional<State> presentState = stateRepo.findById(student.getStateId());
				
				if(presentState.isPresent()) {
					
					Optional<City> presentCity = cityRepo.findById(student.getCityId());
					
					if(presentCity.isPresent()) {
						
						System.out.println(student);
						LocalDate createdDate = student.getCreatedOnDate();
						
						System.out.println(createdDate.getDayOfMonth());
						System.out.println(LocalDate.now().getDayOfMonth());
					 	System.out.println(createdDate.getDayOfMonth()==LocalDate.now().getDayOfMonth());
					    
					    if(createdDate.getDayOfMonth()==LocalDate.now().getDayOfMonth()) {
					    	
					   
					    	
//					    	System.out.println("inside if " + student);
					    	
					    	return studentRepo.save(student);
					    	
					    }
					    else if(createdDate.getDayOfMonth()<LocalDate.now().getDayOfMonth()) {
					    	
					    	throw new DateException("Created date cannot be past date");
					    }
					    else if(createdDate.getDayOfMonth()>LocalDate.now().getDayOfMonth()) {
					    	
					    	throw new DateException("Created date cannot be future date");
					    }
						
					}
					else {
						throw new CityException("No city present with this id " + student.getCityId());
					}
					
				}
				else {
					throw new StateException("No state present with this id " + student.getStateId());
				}
				
			}
			else {
				throw new CountryException("No country present with this id " +  student.getCountryId());
			}
			
			}
			else {
				throw new UniversityException("No university present with this id " +  student.getUniversityId());
			}
			
		}
		else {
			throw new StudentException("Student already present with this rollNo " + student.getRollNumber());
		}
		return presentStudent;
	}

	@Override
	public Student updateStudent(Student student, Integer rollNo)
			throws StudentException, CityException, CountryException, StateException, UniversityException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String generateExcel(HttpServletResponse response, Integer rollNumber, String degreeName) throws IOException, StudentException {
		
//		Student presentStudent =  studentRepo.findByRollNumber(rollNumber);
//		
//		University studentUniversity = universityRepo.findByUniversityId(presentStudent.getUniversityId());
//		
//		Degree studentDegree  = degreeRepo.findByDegreeName(degreeName);
//		
//		System.out.println(rollNumber);
//		System.out.println(studentUniversity.getUniversityName());
//		System.out.println(studentDegree.getDegreeName());
//		System.out.println(studentDegree.getAcademicYear());
//		
//		List<Subject> studentSubjectList = subjectRepo.findSubjectList(studentDegree.getDegreeId());
//		
//		studentSubjectList.forEach(s-> System.out.println(s));
//		
//		List<Marks> marksList = marksRepo.findBySubjectIdList(20);
//		
//		System.out.println(marksList);
		
//		Student presentStudent =  studentRepo.findByRollNumber(rollNumber);
//		
//		Degree studentDegree  = degreeRepo.findByDegreeName(degreeName);
//		
//		List<Subject> studentSubjectList = subjectRepo.findSubjectList(studentDegree.getDegreeId());
//		
//		System.out.println(presentStudent);
//		System.out.println(studentDegree);
//		
//		studentSubjectList.forEach(s-> System.out.println(s));
//		
		 List<ReportCard> reportCard =  marksRepo.findAllDetails(rollNumber,degreeName);
		 
		 System.out.println(reportCard);
		 reportCard.forEach(s-> System.out.println(s));
		 
		 String message = "Unable to create Excel";
		 
		 return "done";
		
		
//		select * from marks m inner join student s on s.student_id = m.student_id inner join subject s2 on m.subject_id = s2.subject_id where s.roll_number =102;
		
//		List<Marks> l = marksRepo.getHash(rollNumber);
		
//		HashMap<Integer, Integer> hashMap = new HashMap<>();
//		
//		for(Marks k:l) {
//			hashMap.put(k.getStudentId(), k.getSubjectId());
//		}
//		System.out.println(hashMap);
		
		
		
		
	}

	@Override
	public String generatePdf(HttpServletResponse response) throws IOException, StudentException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}
