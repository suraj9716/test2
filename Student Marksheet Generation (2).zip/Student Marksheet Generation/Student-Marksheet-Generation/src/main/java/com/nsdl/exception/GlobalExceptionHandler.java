package com.nsdl.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(StudentException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(StudentException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(SubjectException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(SubjectException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(UniversityException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(UniversityException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(StateException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(StateException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(MarksException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(MarksException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(GradeException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(GradeException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(DegreeException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(DegreeException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(CountryException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(CountryException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(CityException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(CityException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(DateException.class)
	public ResponseEntity<MyErrorDetails> getStudentException(DateException se, WebRequest we){
		
		MyErrorDetails myError = new MyErrorDetails();
		
		myError.setMessage(se.getMessage());
		myError.setDescription(we.getDescription(false));
		myError.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<MyErrorDetails>(myError,HttpStatus.BAD_REQUEST);
	}

}
