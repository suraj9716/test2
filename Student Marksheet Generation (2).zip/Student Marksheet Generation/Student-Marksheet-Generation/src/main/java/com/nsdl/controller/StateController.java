package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.CountryException;
import com.nsdl.exception.StateException;
import com.nsdl.model.State;
import com.nsdl.service.StateService;

@RestController
public class StateController {

	@Autowired
	private StateService stateService;
	
	@PostMapping("/addState")
	public ResponseEntity<State> addStateHandler(@RequestBody State state) throws StateException, CountryException{
		
		return new ResponseEntity<State>(stateService.addState(state), HttpStatus.OK);
	}
	
	@PutMapping("/updateState/{name}")
	public ResponseEntity<State> updateStateHandler(@RequestBody State state, @PathVariable("name") String name) throws StateException, CountryException{
		
		return new ResponseEntity<State>(stateService.updateState(state,name), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteState/{stateName}")
	public ResponseEntity<String> deleteStateHandler(@PathVariable("stateName") String stateName) throws StateException{
		
		return new ResponseEntity<String>(stateService.deleteState(stateName), HttpStatus.OK);
	}
	
	@GetMapping("/getStateDetails/{stateName}")
	public ResponseEntity<State> getStateDetailsHandler(@PathVariable("stateName") String stateName) throws StateException{
		
		return new ResponseEntity<State>(stateService.getStateDetails(stateName), HttpStatus.OK);
	}
}
