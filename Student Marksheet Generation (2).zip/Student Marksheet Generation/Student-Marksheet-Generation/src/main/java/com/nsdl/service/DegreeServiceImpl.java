package com.nsdl.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.DegreeException;
import com.nsdl.exception.UniversityException;
import com.nsdl.model.Degree;
import com.nsdl.model.University;
import com.nsdl.repository.DegreeRepo;
import com.nsdl.repository.UniversityRepo;

@Service
public class DegreeServiceImpl implements DegreeService {
	
	@Autowired
	private DegreeRepo degreeRepo;
	
	@Autowired
	private UniversityRepo universityRepo;

	@Override
	public Degree addDegree(Degree degree) throws DegreeException, UniversityException {
		
		 Degree presentDegree =  degreeRepo.findByDegreeName(degree.getDegreeName());
		
		 if(presentDegree==null) {
			 
			Optional<University> presentUniversity =  universityRepo.findById(degree.getUniversityId());
			
			if(presentUniversity.isPresent()) {
				
			return degreeRepo.save(degree);
			
			}
			else {
				throw new UniversityException("No university present with this id " + degree.getUniversityId());
			}
		 }
		 else {
			 throw new DegreeException("Degree already present with this name "  + degree.getDegreeName());
		 }
	}

	@Override
	public Degree updateDegree(Degree degree, String degreeName) throws DegreeException, UniversityException {
		
		Degree presentDegree =  degreeRepo.findByDegreeName(degreeName);
		
		if(presentDegree!=null) {
			
			 Optional<University> presentUniversity =  universityRepo.findById(degree.getUniversityId());
			 
			 if(presentUniversity.isPresent()) {
				 
				 presentDegree.setDegreeId(presentDegree.getDegreeId());
				 presentDegree.setCreatedBy(degree.getDegreeName());
				 presentDegree.setAcademicYear(degree.getAcademicYear());
				 presentDegree.setCreatedBy(degree.getCreatedBy());
				 presentDegree.setUniversityId(degree.getUniversityId());
				 presentDegree.setUpdatedBy(degree.getUpdatedBy());
				 presentDegree.setDegreeName(degree.getDegreeName());
				 
				 return degreeRepo.save(presentDegree);
			 }
			 else {
				 throw new UniversityException("No university present with this id " + degree.getUniversityId());
			 }
			
		}
		else {
			throw new DegreeException("No degree present with this name " + degreeName);
		}
	}

	@Override
	public String deleteDegree(String degreeName) throws DegreeException {
		
		String message = "technical Error";
		
		Degree presentDegree =  degreeRepo.findByDegreeName(degreeName);
		
		if(presentDegree!=null) {
			degreeRepo.delete(presentDegree);
		return message = "Degree Deleted Successfully";
			
		}
		else {
			throw new DegreeException("No degree present with this name "  + degreeName);
		}
	}

	@Override
	public Degree getDegreeDetails(String degreeName) throws DegreeException {
		
		Degree presentDegree =  degreeRepo.findByDegreeName(degreeName);
		
		if(presentDegree!=null) {
			return presentDegree;
		}
		else {
			throw new DegreeException("No degree present with this name " + degreeName);
		}
	}

}
