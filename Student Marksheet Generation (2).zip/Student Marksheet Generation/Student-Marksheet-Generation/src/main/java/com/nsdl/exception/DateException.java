package com.nsdl.exception;

public class DateException extends Exception {

	public DateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
