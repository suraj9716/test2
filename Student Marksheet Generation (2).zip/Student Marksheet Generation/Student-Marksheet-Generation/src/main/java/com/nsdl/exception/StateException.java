package com.nsdl.exception;

public class StateException extends Exception {

	public StateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
