package com.nsdl.exception;

public class StudentException extends Exception {

	public StudentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
