package com.nsdl.exception;

public class SubjectException extends Exception {

	public SubjectException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SubjectException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
