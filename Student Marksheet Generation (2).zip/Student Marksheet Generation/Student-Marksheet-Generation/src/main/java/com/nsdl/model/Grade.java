package com.nsdl.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Grade {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer gradeId;
	private String createdBy;
	private String gradeName;
	private Integer rangeFrom;
	private Integer rangeTo;
	private Integer subjectId;
	private String updatedBy;
	
	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Grade(Integer gradeId, String createdBy, String gradeName, Integer rangeFrom, Integer rangeTo,
			Integer subjectId, String updatedBy) {
		super();
		this.gradeId = gradeId;
		this.createdBy = createdBy;
		this.gradeName = gradeName;
		this.rangeFrom = rangeFrom;
		this.rangeTo = rangeTo;
		this.subjectId = subjectId;
		this.updatedBy = updatedBy;
	}
	public Integer getGradeId() {
		return gradeId;
	}
	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getGradeName() {
		return gradeName;
	}
	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	public Integer getRangeFrom() {
		return rangeFrom;
	}
	public void setRangeFrom(Integer rangeFrom) {
		this.rangeFrom = rangeFrom;
	}
	public Integer getRangeTo() {
		return rangeTo;
	}
	public void setRangeTo(Integer rangeTo) {
		this.rangeTo = rangeTo;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "Grade [gradeId=" + gradeId + ", createdBy=" + createdBy + ", gradeName=" + gradeName + ", rangeFrom="
				+ rangeFrom + ", rangeTo=" + rangeTo + ", subjectId=" + subjectId + ", updatedBy=" + updatedBy + "]";
	}
	
	

}
