package com.nsdl.exception;

@SuppressWarnings("serial")
public class CountryException extends RuntimeException{

	public CountryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CountryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
