package com.nsdl.service;

import com.nsdl.exception.DegreeException;
import com.nsdl.exception.UniversityException;
import com.nsdl.model.Degree;

public interface DegreeService {
	
	public Degree addDegree(Degree degree) throws DegreeException, UniversityException;
	public Degree updateDegree(Degree degree, String degreeName) throws DegreeException, UniversityException;
	public String deleteDegree(String degreeName) throws DegreeException;
	public Degree getDegreeDetails(String degreeName) throws DegreeException;

}
