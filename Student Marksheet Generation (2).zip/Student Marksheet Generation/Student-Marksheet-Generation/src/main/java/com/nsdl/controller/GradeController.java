package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.GradeException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Grade;
import com.nsdl.service.GradeService;

@RestController
public class GradeController {
	
	@Autowired
	private GradeService gradeService;
	
	@PostMapping("/addGrade")
	public ResponseEntity<Grade> addGradeHandler(@RequestBody Grade grade) throws GradeException, SubjectException{
		
		return new ResponseEntity<Grade>(gradeService.addGrade(grade), HttpStatus.OK);
	}
	
	@PutMapping("/updateGrade/{subjectId}")
    public ResponseEntity<Grade> updateGradeHandler(@RequestBody Grade grade, @PathVariable("subjectId") Integer subjectId) throws GradeException, SubjectException{
		
		return new ResponseEntity<Grade>(gradeService.updateGrade(grade, subjectId), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteGrade/{gradeName}")
	 public ResponseEntity<String> deleteGradeHandler(@PathVariable("gradeName") String gradeName) throws GradeException{
			
			return new ResponseEntity<String>(gradeService.deleteGrade(gradeName), HttpStatus.OK);
	}
	
	@GetMapping("/getGradeDetails/{gradeName}")
	public ResponseEntity<Grade> getGradeDetailsHandler(@PathVariable("gradeName") String gradeName) throws GradeException{
		
		return new ResponseEntity<Grade>(gradeService.getGradeDetails(gradeName), HttpStatus.OK);
	}

}
