package com.nsdl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nsdl.model.City;

public interface CityRepo extends JpaRepository<City, Integer> {
	
	public City findByCityName(String cityName);

}
