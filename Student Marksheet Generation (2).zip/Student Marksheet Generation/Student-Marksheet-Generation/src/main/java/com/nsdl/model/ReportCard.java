package com.nsdl.model;

public class ReportCard {
	
	private Integer StudentId;
	private Integer subjectId;
	private Integer marksObtained;
	private Integer rollNumber;
	private Integer universityId;
	private Integer degreeId;
	private Integer minMarks;
	private Integer totalMarks;
	private String subjectName;
	private String year;
	private String studentName;
	private String gradeName;
	private String degreeName;
	
	public ReportCard() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReportCard(Integer studentId, Integer subjectId, Integer marksObtained, Integer rollNumber,
			Integer universityId, Integer degreeId, Integer minMarks, Integer totalMarks, String subjectName,
			String year, String studentName, String gradeName, String degreeName) {
		super();
		StudentId = studentId;
		this.subjectId = subjectId;
		this.marksObtained = marksObtained;
		this.rollNumber = rollNumber;
		this.universityId = universityId;
		this.degreeId = degreeId;
		this.minMarks = minMarks;
		this.totalMarks = totalMarks;
		this.subjectName = subjectName;
		this.year = year;
		this.studentName = studentName;
		this.gradeName = gradeName;
		this.degreeName = degreeName;
	}

	public Integer getStudentId() {
		return StudentId;
	}

	public void setStudentId(Integer studentId) {
		StudentId = studentId;
	}

	public Integer getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public Integer getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(Integer marksObtained) {
		this.marksObtained = marksObtained;
	}

	public Integer getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}

	public Integer getUniversityId() {
		return universityId;
	}

	public void setUniversityId(Integer universityId) {
		this.universityId = universityId;
	}

	public Integer getDegreeId() {
		return degreeId;
	}

	public void setDegreeId(Integer degreeId) {
		this.degreeId = degreeId;
	}

	public Integer getMinMarks() {
		return minMarks;
	}

	public void setMinMarks(Integer minMarks) {
		this.minMarks = minMarks;
	}

	public Integer getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(Integer totalMarks) {
		this.totalMarks = totalMarks;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}

	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	@Override
	public String toString() {
		return "ReportCard [StudentId=" + StudentId + ", subjectId=" + subjectId + ", marksObtained=" + marksObtained
				+ ", rollNumber=" + rollNumber + ", universityId=" + universityId + ", degreeId=" + degreeId
				+ ", minMarks=" + minMarks + ", totalMarks=" + totalMarks + ", subjectName=" + subjectName + ", year="
				+ year + ", studentName=" + studentName + ", gradeName=" + gradeName + ", degreeName=" + degreeName
				+ "]";
	}


	
	
}
