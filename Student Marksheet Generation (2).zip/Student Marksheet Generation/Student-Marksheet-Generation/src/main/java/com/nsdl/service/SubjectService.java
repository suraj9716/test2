package com.nsdl.service;

import com.nsdl.exception.DegreeException;
import com.nsdl.exception.SubjectException;
import com.nsdl.model.Subject;

public interface SubjectService {
	
	public Subject addSubject(Subject subject) throws SubjectException, DegreeException;
	public Subject updateSubject(Subject subject, String subjectName) throws SubjectException,DegreeException;
	public String deleteSubject(String subjectName) throws SubjectException;
	public Subject getSubjectDetails(String subjectName) throws SubjectException;

}
