package com.nsdl.exception;

public class MarksException extends Exception {

	public MarksException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MarksException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
