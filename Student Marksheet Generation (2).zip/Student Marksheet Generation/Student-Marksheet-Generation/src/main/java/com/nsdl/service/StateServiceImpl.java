package com.nsdl.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nsdl.exception.CountryException;
import com.nsdl.exception.StateException;
import com.nsdl.model.Country;
import com.nsdl.model.State;
import com.nsdl.repository.CountryRepo;
import com.nsdl.repository.StateRepo;

@Service
public class StateServiceImpl implements StateService {
	
	
	@Autowired
	private StateRepo stateRepo;

	@Autowired
	private CountryRepo countryRepo;
	
	@Override
	public State addState(State state) throws StateException,CountryException {
		
		State presentState =  stateRepo.findByStateName(state.getStateName());
		
		if(presentState!=null) {
			throw new StateException("State Already present with this name " + presentState.getStateName());
		}
		else {
			
			 Country presentCountry =  countryRepo.findByCountryId(state.getCountryId());
			 
			 if(presentCountry!=null) {
				 
				 return stateRepo.save(state);
			 }
			 else {
				 throw new CountryException("No Country present with this Id " + state.getCountryId());
			 }
			
		
		}

	}

	@Override
	public State updateState(State state, String stateName) throws StateException, CountryException {
		
		State presentState =  stateRepo.findByStateName(stateName);
		
		Optional<State> presentState1 =  stateRepo.findById(state.getStateId());
		
		if(presentState!=null) {
		
			if(presentState1.isPresent()) {
				
				 Country presentCountry =  countryRepo.findByCountryId(state.getCountryId());
					
					if(presentCountry!=null) {
						
						presentState.setStateId(presentState.getStateId());
						presentState.setStateName(state.getStateName());
						presentState.setCountryId(state.getCountryId());
						
						return stateRepo.save(presentState);
					}
					else {
						throw new CountryException("No country Found with this Id "+state.getCountryId());
					}
			}
			
			
		}
		throw new StateException("No State Found with this Name " + stateName); 
	}

	@Override
	public String deleteState(String stateName) throws StateException {
		
		String message = "Technical Error";
		
		State presentState =  stateRepo.findByStateName(stateName);
		
		if(presentState!=null) {
			
			stateRepo.delete(presentState);
			
			return message = "State Deleted Successfully";
		}
		else {
			throw new StateException("No state present with this name " +  stateName);
		}
		
	}

	@Override
	public State getStateDetails(String stateName) throws StateException {
		
		State presentState =  stateRepo.findByStateName(stateName);
		
		if(presentState!=null) {
			
            return presentState;
    		   
		}
		else {
			throw new StateException("No state present with this name " +  stateName);
		}
	}


}
