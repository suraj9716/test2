package com.nsdl.exception;

public class GradeException  extends Exception{

	public GradeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GradeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
