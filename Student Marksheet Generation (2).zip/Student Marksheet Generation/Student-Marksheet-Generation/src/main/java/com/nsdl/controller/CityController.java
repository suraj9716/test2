package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.CityException;
import com.nsdl.exception.StateException;
import com.nsdl.model.City;
import com.nsdl.service.CityService;

@RestController
public class CityController {
	
	@Autowired
	private CityService cityService;
	
	@PostMapping("/addCity")
	public ResponseEntity<City> addCityHandler(@RequestBody City city) throws CityException, StateException{
		
		return new ResponseEntity<City>(cityService.addCity(city), HttpStatus.OK);
	}
	
	@PutMapping("/updateCity/{cityName}")
	public ResponseEntity<City> updateCityHandler(@RequestBody City city , @PathVariable("cityName") String cityName) throws CityException, StateException{
		
		return new ResponseEntity<City>(cityService.updateCity(city, cityName),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteCity/{cityName}")
	public ResponseEntity<String> deleteCityHandler(@PathVariable("cityName") String cityName) throws CityException{
		
		return new ResponseEntity<String>(cityService.deleteCity(cityName), HttpStatus.OK);
	}
	
	@GetMapping("/getCityDetails/{cityName}")
	public ResponseEntity<City> getCityDetailsHandler(@PathVariable("cityName") String cityName) throws CityException{
		
		return new ResponseEntity<City>(cityService.getCityDetails(cityName), HttpStatus.OK);
	}

}
