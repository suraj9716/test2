package com.nsdl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.exception.DegreeException;
import com.nsdl.exception.UniversityException;
import com.nsdl.model.Degree;
import com.nsdl.service.DegreeService;

@RestController
public class DegreeController {
	
	@Autowired
	private DegreeService degreeService;
	
	@PostMapping("/addDegree")
	public ResponseEntity<Degree> addDegreeHandler(@RequestBody Degree degree) throws DegreeException, UniversityException{
		
		return new ResponseEntity<Degree>(degreeService.addDegree(degree), HttpStatus.OK);
	}
	
	@PutMapping("/updateDegree/{degreeName}")
	public ResponseEntity<Degree> updateDegreeHandler(@RequestBody Degree degree, @PathVariable("degreeName") String degreeName) throws DegreeException, UniversityException{
		
		return new ResponseEntity<Degree>(degreeService.updateDegree(degree, degreeName), HttpStatus.OK);
	}

	@DeleteMapping("/deleteDegree/{degreeName}")
	public ResponseEntity<String> deleteDegreeHandler(@PathVariable("degreeName") String degrreName) throws DegreeException{
		
		return new ResponseEntity<String>(degreeService.deleteDegree(degrreName), HttpStatus.OK);
	}
	
	@GetMapping("/getDegreeDetails/{degreeName}")
	public ResponseEntity<Degree> getDegreeDetailsHandler(@PathVariable("degreeName") String degreeName) throws DegreeException{
		
		return new ResponseEntity<Degree>(degreeService.getDegreeDetails(degreeName), HttpStatus.OK);
	}
}
