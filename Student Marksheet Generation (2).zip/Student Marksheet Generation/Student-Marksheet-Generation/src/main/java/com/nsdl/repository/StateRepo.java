package com.nsdl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nsdl.model.State;

public interface StateRepo extends JpaRepository<State, Integer> {
	
	public State findByStateName(String stateName);

}
